"""Task-independent Agentic-style control instructions for a subscription port.

Method reference: https://research.nvidia.com/labs/srl/projects/astranomy/
This is a LIBERO/Panda adaptation, not the report's native Codex implementation.
"""
from __future__ import annotations

from typing import Mapping

from .astranomy_agentic_geometry import validate_geometry_metadata
from .distance_tasks import resolve_distance_task


PROMPT_VERSION = "astranomy-agentic-panda-expanded-v1"


def instructions(task_key: str = "bowl_plate", geometry: Mapping | None = None) -> str:
    """Only the official task sentence varies; no task-specific recipe is added."""
    task = resolve_distance_task(task_key)
    if geometry is not None:
        validate_geometry_metadata(geometry)
    return f"""Interface {PROMPT_VERSION}. You control one simulated Franka Panda with a PandaGripper.
Task: {task.prompt}

Use the current external and wrist RGB images, measured robot state, camera calibration, and this episode's action feedback. Retain the full chronological text and visual history. Images, robot state and camera poses in one observation are synchronized; interpret an older image with its own calibration. There are no demonstrations or prior task trajectories. Object poses, depth, segmentation, contacts, rewards and subtask-progress labels are not supplied.

Before moving, formulate a brief sequence of subgoals from the task and images. Keep track of the current subgoal, evaluate measured outcomes, and revise your plan when necessary. You may express a short plan or update in text. Then call execute_eef_target exactly once with only target and steps. Optional shell, code, web, image-editing, delegation and other tools are unavailable. There is no done or give_up tool. Only the environment evaluator determines success; an issued command, grasp-looking image, or reached pose does not establish completion.

The complete target is [x,y,z,qw,qx,qy,qz,gripper]. XYZ is ABSOLUTE in the fixed simulation world frame, in metres. World +z is upward. Positive world directions do not rotate with the wrist. The position locates gripper0_grip_site between the fingers. The unit wxyz quaternion gives robot0_right_hand orientation in world coordinates; it is not the site's rotated visualization frame. Supply all eight entries every time. Gripper is 0=open or 1=closed. The robot_state has this same eight-entry pose convention and a measured continuous closure value in its last entry; it is feedback, not proof of attachment. The joint_positions field contains seven measured arm joint angles in radians.

Choose an integer steps from 1 through 5. The target must be no more than 0.05 m translation and 0.35 rad rotation from the latest measured pose. One unchanged target is held for the selected steps at the native 20 Hz (0.05 s per step). It is not a waypoint sequence or an arrival-waiting macro. Each step recomputes world-frame pose error from measured state and limits the requested increment to 0.02 m translation and 0.1 rad rotation before the native OSC controller. Actual displacement may be smaller. The requested gripper command is applied on every step concurrently with arm motion. Simulation pauses during model inference. Shorten segments near contact and judge arrival, finger motion and attachment from subsequent observations and measured tracking error.

Each observation's geometry contains only camera calibration and fixed robot dimensions. Camera position_world_m and rotation_world_from_camera map OpenGL camera coordinates to world: p_world = p_camera_origin + R * p_camera. Camera +X points image-right, +Y image-up, and -Z forward. The supplied RGB is upright and uncropped: pixel u grows right and v grows down. For camera point [X,Y,Z] with Z<0, u=cx+fx*X/(-Z) and v=cy-fy*Y/(-Z), using focal_length_px and principal_point_px. A pixel specifies a ray; depth must be inferred from visual evidence. The wrist pose_source is observed_robot_pose_fixed_mount: its pose is derived from this observation's measured robot pose and fixed wrist-camera mounting transform, synchronizing it with the same RGB rather than a later simulator state. The external camera is fixed in world coordinates. Do not use image axes directly as world actions or assume the image center is the grasp point.

The Panda hand's local +Z is the finger approach direction and local Y is the jaw separation axis; both rotate with the quaternion. The grip site is 0.097 m along hand-local +Z from the hand origin. Action XYZ ALREADY locates the grip site: do not add another 0.097 m offset. For symmetric fingers, pad centers have midpoint [0,0,-0.0036] m relative to the grip site in hand axes. Each pad measures [0.016,0.008,0.016] m along those axes. Nominal open inner gap is 0.079 m. These fixed asset dimensions explain the tool, not scene clearance or current contact. Assess the complete hand and fingers in both views when positioning; visible object centers need not be suitable contact points.
"""
